jQuery(function ($) {
    var download_button = $('#configuration-download');

    // Create a blob object.
    var bb = new Blob(
        ["---\ninput:\n  values: {}\n  default_values:\n    name: arachni_name\n    user: arachni_user\n    usr: arachni_user\n    pass: 5543!%arachni_secret\n    txt: arachni_text\n    num: '132'\n    amount: '100'\n    mail: arachni@email.gr\n    account: '12'\n    id: '1'\n  without_defaults: false\n  force: false\nbrowser_cluster:\n  local_storage: {}\n  wait_for_elements: {}\n  pool_size: 6\n  job_timeout: 25\n  worker_time_to_live: 100\n  ignore_images: false\n  screen_width: 1600\n  screen_height: 1200\naudit:\n  parameter_values: true\n  exclude_vector_patterns:\n  - j_idt\n  - javax.faces.ViewState\n  include_vector_patterns: []\n  link_templates: []\n  links: true\n  forms: true\n  ui_inputs: true\n  ui_forms: true\ndatastore:\n  report_path: pentest.afr\nhttp:\n  user_agent: Arachni/v2.0dev\n  request_timeout: 10000\n  request_redirect_limit: 5\n  request_concurrency: 20\n  request_queue_size: 100\n  request_headers: {}\n  response_max_size: 500000\n  cookies: {}\nsession: {}\nscope:\n  redundant_path_patterns: {}\n  dom_depth_limit: 10\n  exclude_file_extensions: []\n  exclude_path_patterns: []\n  exclude_content_patterns: []\n  include_path_patterns: []\n  restrict_paths: []\n  extend_paths:\n  - users/list1.xhtml\n  - users/list2.xhtml\n  - index.xhtml\n  url_rewrites: {}\nchecks:\n- sql_injection_timing\n- sql_injection\n- sql_injection_differential\n- http_only_cookies\n- http_put\n- os_cmd_injection\n- os_cmd_injection_timing\n- xss_tag\n- xss_dom\n- xss_event\n- xss_path\n- xss_dom_script_context\n- xss_script_context\n- insecure_cross_domain_policy_access\n- insecure_cookies\n- insecure_cors_policy\n- insecure_cross_domain_policy_headers\n- insecure_client_access_policy\n- allowed_methods\n- csrf\n- code_injection\n- directory_listing\n- emails\n- form_upload\n- session_fixation\n- xpath_injection\nplatforms:\n- linux\n- pgsql\n- oracle\n- tomcat\n- java\n- jsf\nplugins: {}\nno_fingerprinting: false\nauthorized_by: \nurl: http://david-virtualbox:8080/\n"],
        { type : 'application/yaml' }
    );

    download_button.attr( 'href', window.URL.createObjectURL( bb ) );
    download_button.attr( 'download', 'david-virtualbox-profile.afp' );
});
